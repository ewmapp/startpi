<?= $this->extend('layout/theme') ?>

<?= $this->section('styles') ?>
<style>
  .wrapper {
    position: absolute;
    top: 0;
    left: 0;
    animation: scroll 70s linear infinite;
    background: url("<?php echo site_url('/'); ?>assets/img/background.jpg"), #111111;
    background-size: cover;
    color: #eee;
    height: 100vh;
    min-width: 360px;
    width: 100%;
    display: flex;
    justify-content: center;
    align-items: center;
    perspective: 2000px;
    perspective-origin: 50% 50%;
    z-index: 0;
  }

  @keyframes scroll {
    100% {
      background-position: 0px -3000px;
    }
  }

  @media (prefers-reduced-motion) {
    .wrapper {
      animation: scroll 200s linear infinite;
    }
  }

  .cover-container {
    z-index: 10;
  }
</style>
<?= $this->endSection() ?>

<?= $this->section('title') ?>
<?= $pg_title ?>
<?= $this->endSection() ?>

<?= $this->section('content') ?>
<article class="wrapper">
</article>

<div class="cover-container d-flex w-100 h-100 p-3 mx-auto flex-column">
  <header class="mb-auto">
    <div>
      <h1 class="text-center mb-0">CREDENCIAMENTO</h1>
    </div>
  </header>

  <main class="px-3">
    <div id="start">
      <img src="<?php echo site_url('/'); ?>assets/img/logo.png" class="img-fluid mb-4" alt="Logo">
      <div class="m-auto">
        <p class="lead fs-3">1ª Mostra Nacional de Experiências da Rede de Laboratórios de Saúde Pública</p>
        <p class="lead">
          <a href="#" class="btn btn-lg btn-secondary fw-bold border-white bg-white mt-4">Iniciar</a>
        </p>
      </div>
    </div>
    <div id="login" style="display: none;">
      <p class="lead fs-3">1ª Mostra Nacional de Experiências da Rede de Laboratórios de Saúde Pública</p>
    </div>
  </main>



  <footer class="mt-auto text-white-50">
    <p>
      <img src="<?php echo site_url('/'); ?>assets/img/assinatura.png" class="img-fluid" alt="Organização">
    </p>
  </footer>
</div>
<?= $this->endSection() ?>


<?= $this->section('scripts') ?>
<script>
  $(document).ready(() => {
    $(".btn-secondary").click(() => {
      console.log('clicj');
      $("#start").fadeOut(400);
      $("#login").delay(400).fadeIn(400);
    });
  });
</script>
<?= $this->endSection() ?>