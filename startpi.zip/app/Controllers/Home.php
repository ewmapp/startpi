<?php

namespace App\Controllers;

class Home extends BaseController
{
    public function index()
    {
        $data = [
            'pg_title' => 'Home',
        ];
        return view('home', $data);
    }
}
